from .base import BMCONFIGS
from .backboned import MCONFIGS


ALL_MCONFIGS = dict(**BMCONFIGS, **MCONFIGS)
